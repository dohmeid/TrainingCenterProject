package com.example.trainingcenterproject;

import android.graphics.Bitmap;

public class Course {
    private int course_num;
    private String title;
    private String symbol;
    private String main_topics;
    private String prereq;
    private Bitmap photo;

    public Course(){

    }

    public Course(int course_num, String title,String symbol, String main_topics, String prereq, Bitmap photo) {
        this.course_num = course_num;
        this.title = title;
        this.symbol = symbol;
        this.main_topics = main_topics;
        this.prereq = prereq;
        this.photo = photo;

    }



    public int getCourse_num() {
        return course_num;
    }

    public void setCourse_num(int course_num) {
        this.course_num = course_num;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMain_topics() {
        return main_topics;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public void setMain_topics(String main_topics) {
        this.main_topics = main_topics;
    }

    public String getPrereq() {
        return prereq;
    }

    public void setPrereq(String prereq) {
        this.prereq = prereq;
    }

    public Bitmap getPhoto() {
        return photo;
    }

    public void setPhoto(Bitmap photo) {
        this.photo = photo;
    }

    @Override
    public String toString() {
        return "Course{" +
                "course_num=" + course_num +
                ", title='" + title + '\'' +
                ", symbol='" + symbol + '\'' +
                ", main_topics='" + main_topics + '\'' +
                ", prereq='" + prereq + '\'' +
                ", photo='" + photo + '\'' +
                '}';
    }
}
